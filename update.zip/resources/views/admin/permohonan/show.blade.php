@extends('layouts.app')

@section('content')
<div class="space-y-8 animate-fade-in lg:px-8">
    
    <!-- DASHBOARD-STYLE HEADER SECTION -->
    <div class="bg-gradient-to-br from-[#004a99] via-[#005bb5] to-[#006ccf] rounded-[2rem] p-10 md:p-12 shadow-xl text-white relative overflow-hidden mb-10">
        <div class="absolute -right-20 -top-20 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
        
        <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div class="space-y-6">
                <div class="inline-flex items-center gap-3 px-5 py-2 bg-[#ffc107] rounded-full text-[#004a99]">
                    <span class="w-2.5 h-2.5 bg-[#004a99] rounded-full animate-ping"></span>
                    <h2 class="text-[11px] font-black uppercase tracking-[3px]">Review Permohonan: Aktif</h2>
                </div>
                
                <div>
                    <h1 class="text-3xl md:text-5xl font-black tracking-tight leading-tight text-white mb-2">
                        Detail <span class="text-[#ffc107]">Permohonan</span>
                    </h1>
                    <p class="text-blue-50 text-lg font-bold max-w-2xl opacity-90">Review pengajuan informasi publik dari masyarakat secara mendalam.</p>
                </div>
            </div>

            <div class="flex items-center gap-4">
                <a href="{{ route('admin.permohonan.index') }}" class="px-6 py-4 bg-white/10 border border-white/20 text-white font-black text-xs uppercase tracking-widest rounded-2xl hover:bg-white/20 transition-all flex items-center">
                    <i class="fas fa-arrow-left mr-3"></i> Kembali
                </a>
            </div>
        </div>
    </div>
            
            @php
                $statusColors = [
                    'pending'   => ['bg' => 'bg-yellow-100', 'text' => 'text-yellow-600', 'label' => 'MENUNGGU'],
                    'approved'  => ['bg' => 'bg-green-100',  'text' => 'text-green-600',  'label' => 'DISETUJUI'],
                    'selesai'   => ['bg' => 'bg-blue-100',   'text' => 'text-blue-700',   'label' => 'SELESAI'],
                    'diproses'  => ['bg' => 'bg-sky-100',    'text' => 'text-sky-700',    'label' => 'DIPROSES'],
                    'ditolak'   => ['bg' => 'bg-red-100',    'text' => 'text-red-600',    'label' => 'DITOLAK'],
                    'completed' => ['bg' => 'bg-blue-600',   'text' => 'text-white',      'label' => 'SELESAI'],
                    'rejected'  => ['bg' => 'bg-red-100',    'text' => 'text-red-600',    'label' => 'DITOLAK'],
                ];
                $st = $statusColors[$permohonan->status ?? 'pending'] ?? ['bg' => 'bg-gray-100', 'text' => 'text-gray-400', 'label' => strtoupper($permohonan->status ?? 'pending')];
            @endphp

        @if(session('success'))
            <div class="bg-green-100 border-l-4 border-green-500 p-4 rounded-xl shadow-sm flex items-center animate-fade-in-down">
                <div class="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mr-3 shadow-lg shadow-green-500/20">
                    <i class="fas fa-check text-white"></i>
                </div>
                <p class="text-green-800 font-bold uppercase text-xs">{{ session('success') }}</p>
            </div>
        @endif

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- MAIN CONTENT (Left) -->
            <div class="lg:col-span-2 space-y-6 text-gray-800">
                
                <!-- USER INFO CARD -->
                <div class="bg-white rounded-3xl shadow-xl ring-1 ring-gray-200 overflow-hidden border-t-4 border-[#ffc107]">
                    <div class="p-8 space-y-6">
                        <h3 class="text-xs font-black text-[#004a99] uppercase tracking-[0.2em] flex items-center mb-6">
                            <i class="fas fa-user-circle mr-3 text-[#ffc107] text-gray-800"></i> Profil Pemohon
                        </h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div class="space-y-1">
                                <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest">Nama Lengkap</label>
                                <p class="text-sm font-bold text-gray-800">{{ $permohonan->nama_pemohon }}</p>
                            </div>
                            <div class="space-y-1">
                                <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest">Email & No. Telp</label>
                                <p class="text-sm font-bold text-gray-800">{{ $permohonan->email }}</p>
                                <p class="text-[10px] font-bold text-[#004a99]">{{ $permohonan->nomor_telepon }}</p>
                            </div>
                            <div class="space-y-1">
                                <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest">Identitas ({{ strtoupper($permohonan->jenis_identitas) }})</label>
                                <p class="text-sm font-bold text-gray-800">{{ $permohonan->nomor_identitas }}</p>
                            </div>
                            <div class="space-y-1">
                                <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest">Pekerjaan</label>
                                <p class="text-sm font-bold text-gray-800">{{ $permohonan->pekerjaan ?: '-' }}</p>
                            </div>
                        </div>

                        <div class="pt-6 border-t border-gray-100 flex items-center justify-between gap-4">
                            <div class="flex-1">
                                <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest">Alamat Domisili</label>
                                <p class="text-xs font-medium text-gray-600 mt-1 leading-relaxed">{{ $permohonan->alamat }}</p>
                            </div>
                            @if($permohonan->foto_ktp)
                            <a href="{{ Storage::url($permohonan->foto_ktp) }}" target="_blank" class="shrink-0 px-4 py-3 bg-blue-50 text-[#004a99] rounded-xl font-bold text-[10px] hover:bg-[#004a99] hover:text-white transition-all">
                                <i class="fas fa-id-card mr-2 text-gray-800"></i> CEK IDENTITAS
                            </a>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- REQUEST INFO CARD -->
                <div class="bg-white rounded-3xl shadow-xl ring-1 ring-gray-200 overflow-hidden border-t-4 border-[#004a99]">
                    <div class="p-8 space-y-6">
                        <h3 class="text-xs font-black text-[#004a99] uppercase tracking-[0.2em] flex items-center mb-6">
                            <i class="fas fa-file-alt mr-3 text-[#ffc107]"></i> Uraian Permohonan
                        </h3>
                        
                        <div class="space-y-4">
                            <div class="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                                <label class="text-[10px] font-black text-[#004a99] uppercase tracking-widest mb-2 block">Jenis Informasi Yang Diminta</label>
                                <h4 class="text-sm font-bold text-gray-800">{{ $permohonan->jenis_informasi }}</h4>
                            </div>

                            <div class="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                                <label class="text-[10px] font-black text-[#004a99] uppercase tracking-widest mb-2 block">Tujuan Penggunaan Informasi</label>
                                <p class="text-xs font-medium text-gray-600 leading-relaxed">{{ $permohonan->deskripsi_permohonan }}</p>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="p-4 bg-blue-50/50 rounded-2xl flex items-center gap-4">
                                    <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-[#004a99] shadow-sm">
                                        <i class="fas fa-print"></i>
                                    </div>
                                    <div>
                                        <p class="text-[9px] font-black text-gray-400 uppercase">Format</p>
                                        <p class="text-[10px] font-bold text-[#004a99]">{{ strtoupper($permohonan->format_informasi) }}</p>
                                    </div>
                                </div>
                                <div class="p-4 bg-blue-50/50 rounded-2xl flex items-center gap-4">
                                    <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-[#004a99] shadow-sm">
                                        <i class="fas fa-calendar-check"></i>
                                    </div>
                                    <div>
                                        <p class="text-[9px] font-black text-gray-400 uppercase">Tgl Daftar</p>
                                        <p class="text-[10px] font-bold text-[#004a99]">{{ $permohonan->created_at->format('d M Y') }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- CUSTOM FIELDS DATA -->
                        @if($permohonan->custom_fields_data && is_array($permohonan->custom_fields_data) && count($permohonan->custom_fields_data) > 0)
                        <div class="mt-10 space-y-4">
                            <h4 class="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] border-b pb-2">Data Kuesioner Tambahan</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                @foreach($permohonan->custom_fields_data as $key => $value)
                                <div class="p-4 bg-gray-50 rounded-xl border border-gray-100">
                                    <p class="text-[9px] font-black text-gray-400 uppercase truncate">{{ str_replace('_', ' ', preg_replace('/^custom_|_\\d+$/', '', $key)) }}</p>
                                    <div class="mt-1">
                                        @if(is_string($value) && str_starts_with($value, 'permohonan/custom'))
                                            <a href="{{ Storage::url($value) }}" target="_blank" class="text-[10px] font-black text-blue-600 hover:text-blue-800">
                                                <i class="fas fa-paperclip mr-1"></i> LIHAT LAMPIRAN
                                            </a>
                                        @else
                                            <p class="text-xs font-bold text-gray-700">{{ is_array($value) ? json_encode($value) : $value }}</p>
                                        @endif
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            </div>

            <!-- ACTION SIDEBAR (Right) -->
            <div class="space-y-6">
                
                <!-- UPDATE STATUS CARD -->
                <div class="bg-white rounded-3xl shadow-xl ring-1 ring-gray-200 overflow-hidden text-gray-800">
                    <div class="p-6 space-y-6">
                        <h3 class="text-xs font-black text-[#004a99] uppercase tracking-widest">Update Progress</h3>
                        
                        <form action="{{ route('admin.permohonan.update', $permohonan->id) }}" method="POST" class="space-y-4">
                            @csrf
                            @method('PUT')
                            
                            <div class="space-y-2">
                                <label class="text-[10px] font-black text-gray-400 uppercase ml-1">Ubah Status</label>
                                <select name="status" id="statusSelect" onchange="toggleFields()" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-bold text-[#004a99] focus:ring-4 focus:ring-blue-500/10 focus:outline-none appearance-none">
                                    <option value="pending"  {{ ($permohonan->status ?? 'pending') == 'pending'  ? 'selected' : '' }}>MENUNGGU</option>
                                    <option value="diproses" {{ ($permohonan->status ?? 'pending') == 'diproses' ? 'selected' : '' }}>SEDANG DIPROSES</option>
                                    <option value="selesai"  {{ ($permohonan->status ?? 'pending') == 'selesai'  ? 'selected' : '' }}>SELESAI / DIPENUHI</option>
                                    <option value="ditolak"  {{ ($permohonan->status ?? 'pending') == 'ditolak'  ? 'selected' : '' }}>DITOLAK</option>
                                </select>
                            </div>

                            {{-- Kategori Laporan --}}
                            <div class="space-y-2">
                                <label class="text-[10px] font-black text-gray-400 uppercase ml-1">Kategori Laporan</label>
                                <select name="kategori_laporan" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-bold text-[#004a99] focus:ring-4 focus:ring-blue-500/10 focus:outline-none appearance-none">
                                    <option value="">-- Pilih Kategori --</option>
                                    <option value="berkala"     {{ $permohonan->kategori_laporan == 'berkala'     ? 'selected' : '' }}>Berkala</option>
                                    <option value="sertamerta"  {{ $permohonan->kategori_laporan == 'sertamerta'  ? 'selected' : '' }}>Serta Merta</option>
                                    <option value="setiapsaat"  {{ $permohonan->kategori_laporan == 'setiapsaat'  ? 'selected' : '' }}>Setiap Saat</option>
                                    <option value="dikecualikan" {{ $permohonan->kategori_laporan == 'dikecualikan' ? 'selected' : '' }}>Dikecualikan</option>
                                </select>
                            </div>

                            {{-- Tanggal Selesai --}}
                            <div class="space-y-2" id="tglSelesaiField">
                                <label class="text-[10px] font-black text-gray-400 uppercase ml-1">Tanggal Selesai</label>
                                <input type="date" name="tanggal_selesai" value="{{ $permohonan->tanggal_selesai ? \Carbon\Carbon::parse($permohonan->tanggal_selesai)->format('Y-m-d') : '' }}" class="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-bold text-[#004a99] focus:ring-4 focus:ring-blue-500/10 focus:outline-none">
                            </div>

                            {{-- Alasan Penolakan (tampil saat ditolak) --}}
                            <div class="space-y-2 hidden" id="alasanField">
                                <label class="text-[10px] font-black text-red-400 uppercase ml-1">Alasan Penolakan <span class="text-red-500">*</span></label>
                                <textarea name="alasan_penolakan_text" rows="3" class="tinymce-editor w-full px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-xs font-bold text-red-700 focus:ring-4 focus:ring-red-500/10 focus:outline-none" placeholder="Tulis alasan penolakan..." >{{ $permohonan->alasan_penolakan_text }}</textarea>
                                <input type="text" name="penolakan_pasal_uu" value="{{ $permohonan->penolakan_pasal_uu }}" class="w-full px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-xs font-bold text-red-700 focus:ring-4 focus:ring-red-500/10 focus:outline-none" placeholder="Dasar hukum penolakan (pasal/UU)">
                            </div>

                            <button type="submit" class="w-full py-4 bg-[#004a99] text-white font-black uppercase tracking-widest text-xs rounded-2xl shadow-lg hover:shadow-blue-500/20 transition-all flex items-center justify-center">
                                <i class="fas fa-save mr-2 text-[#ffc107]"></i> Simpan Perubahan
                            </button>
                        </form>

                        <script>
                        function toggleFields() {
                            const status = document.getElementById('statusSelect').value;
                            document.getElementById('alasanField').classList.toggle('hidden', status !== 'ditolak');
                        }
                        toggleFields();
                        </script>
                    </div>
                </div>

                <!-- ATTACHMENTS CARD -->
                @if($permohonan->berkas_pendukung)
                <div class="bg-[#004a99] rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
                    <div class="absolute -right-10 -top-10 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
                    <h3 class="text-[11px] font-black uppercase tracking-[0.2em] mb-4 flex items-center relative z-10 text-gray-800">
                        <i class="fas fa-paperclip mr-2 text-[#ffc107]"></i> Berkas Pendukung
                    </h3>
                    <div class="relative z-10 bg-white/10 p-4 rounded-2xl backdrop-blur-sm flex items-center gap-3">
                        <div class="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl">
                            <i class="fas fa-file-download text-gray-800"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-[8px] font-bold opacity-60 uppercase truncate">Lampiran Dokumen</p>
                            <a href="{{ Storage::url($permohonan->berkas_pendukung) }}" target="_blank" class="text-[10px] font-black hover:text-[#ffc107] truncate">DOWNLOAD FILE</a>
                        </div>
                    </div>
                </div>
                @endif

                <!-- DANGER ZONE -->
                <div class="p-6 bg-red-50 rounded-3xl border border-red-100 space-y-4">
                    <h3 class="text-[10px] font-black text-red-500 uppercase tracking-widest flex items-center">
                        <i class="fas fa-biohazard mr-2"></i> Danger Zone
                    </h3>
                    <form action="{{ route('admin.permohonan.destroy', $permohonan->id) }}" method="POST" onsubmit="return confirm('Hapus data ini secara permanen?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="w-full py-3 bg-white text-red-500 font-bold text-[10px] rounded-xl border border-red-200 hover:bg-red-500 hover:text-white transition-all uppercase tracking-widest">
                            Hapus Permohonan
                        </button>
                    </form>
                </div>

            </div>
        </div>

    </div>
</div>

<style>
    .animate-fade-in-down { animation: fadeInDown 0.4s ease-out; }
    @keyframes fadeInDown {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
@endsection
