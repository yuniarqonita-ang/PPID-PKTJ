<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PesanKontak extends Model
{
    protected $fillable = [
        'nama',
        'email',
        'telepon',
        'judul',
        'pesan',
        'is_read',
    ];
}
