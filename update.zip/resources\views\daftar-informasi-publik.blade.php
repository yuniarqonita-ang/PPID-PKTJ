<!DOCTYPE html>
<html lang="id">
<head>
    <link rel="icon" type="image/png" href="{{ asset('images/logo-pktj.png') }}">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Informasi Publik - {{ $settings['ppid_nama'] ?? 'Portal PPID PKTJ' }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-blue: #004a99;
            --secondary-gold: #ffc107;
        }
        body { 
            font-family: 'Inter', sans-serif;
            background-color: #f8faff;
            color: #1e293b;
            line-height: 1.6;
        }

        .outfit { font-family: 'Outfit', sans-serif; }

        /* Hero Section */
        .hero-section {
            background: linear-gradient(rgba(0, 74, 153, 0.9), rgba(0, 74, 153, 0.8)), 
                        url('{{ isset($settings["layanan_daftar_hero_image"]) ? asset("storage/halaman/" . $settings["layanan_daftar_hero_image"]) : "https://images.unsplash.com/photo-1521791136064-7986c29535a7?q=80&w=2070" }}');
            background-size: cover;
            background-position: center;
            padding: 120px 0;
            color: white;
        }

        .hero-content { position: relative; z-index: 10; }

        .search-container {
            max-width: 600px;
            margin: 40px auto 0;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            padding: 12px;
            border-radius: 30px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            display: flex;
            gap: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .search-input {
            background: transparent;
            border: none;
            color: white;
            padding: 10px 25px;
            width: 100%;
            font-weight: 600;
            font-size: 1.1rem;
        }

        .search-input::placeholder { color: rgba(255,255,255,0.7); }
        .search-input:focus { outline: none; }

        .btn-search {
            background: var(--secondary-gold);
            color: var(--primary-blue);
            border: none;
            padding: 12px 30px;
            border-radius: 22px;
            font-weight: 900;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn-search:hover { transform: translateY(-3px) scale(1.02); background: #fff; box-shadow: 0 10px 20px rgba(0,0,0,0.1); }

        .content-card {
            background: white;
            padding: 60px;
            border-radius: 40px;
            box-shadow: 0 30px 60px rgba(0, 74, 153, 0.1);
            margin-top: -80px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            position: relative;
            z-index: 20;
            margin-bottom: 80px;
        }

        .section-title {
            color: var(--primary-blue);
            font-weight: 900;
            margin-bottom: 40px;
            border-left: 8px solid var(--secondary-gold);
            padding-left: 25px;
            text-transform: uppercase;
            letter-spacing: -1px;
            font-family: 'Outfit', sans-serif;
            font-size: 2.5rem;
        }
        
        .info-item {
            background: #f8fafc;
            border-radius: 24px;
            padding: 25px 35px;
            margin-bottom: 20px;
            border: 1px solid #e2e8f0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .info-item:hover {
            transform: translateX(15px);
            background: white;
            border-color: var(--primary-blue);
            box-shadow: 0 15px 30px rgba(0, 74, 153, 0.08);
        }

        .info-icon {
            width: 60px;
            height: 60px;
            background: rgba(0, 74, 153, 0.1);
            color: var(--primary-blue);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-right: 25px;
            flex-shrink: 0;
        }

        .btn-download-premium {
            background: var(--primary-blue);
            color: white;
            padding: 12px 25px;
            border-radius: 15px;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn-download-premium:hover {
            background: var(--secondary-gold);
            color: var(--primary-blue);
            transform: scale(1.05);
        }

        .form-label {
            font-weight: 500;
            color: #64748b;
            font-size: 0.95rem;
            margin-bottom: 8px;
        }
    </style>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        .hover-lift { transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .hover-lift:hover { transform: translateY(-5px); box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

    @include('navigation')

    <div class="hero-section">
        <div class="container text-center hero-content">
            <h1 class="display-3 fw-black outfit uppercase">{{ $settings['layanan_daftar_judul_hero'] ?? 'Daftar Informasi Publik' }}</h1>
            <p class="lead opacity-75 mb-0">{{ $settings['layanan_daftar_tagline_hero'] ?? 'Akses Transparan Informasi Publik untuk Masyarakat.' }}</p>
        </div>
    </div>

    <div class="container-fluid px-lg-5">
        <div class="content-card shadow-lg border-0" style="border-radius: 20px;">
            <h1 class="fw-bold mb-4" style="color: #333; font-size: 2.5rem;">Daftar Informasi Publik</h1>


            <!-- Search Form -->
            <form action="{{ route('layanan.daftar-informasi') }}" method="GET" class="mb-5">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label text-muted small fw-bold">Informasi</label>
                        <input type="text" name="informasi" value="{{ request('informasi') }}" class="form-control py-2 border-0 bg-light" style="border-radius: 8px;">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label text-muted small fw-bold">Ringkasan Informasi</label>
                        <input type="text" name="ringkasan" value="{{ request('ringkasan') }}" class="form-control py-2 border-0 bg-light" style="border-radius: 8px;">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label text-muted small fw-bold">Waktu Pembuatan</label>
                        <select name="tahun" class="form-select py-2 border-0 bg-light" style="border-radius: 8px;">
                            <option value="">Pilih Tahun</option>
                            @if(isset($years) && $years->count() > 0)
                                @foreach($years as $year)
                                    <option value="{{ $year }}" {{ request('tahun') == $year ? 'selected' : '' }}>{{ $year }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label text-muted small fw-bold">Penanggung Jawab</label>
                        <select name="penanggung_jawab" class="form-select py-2 border-0 bg-light" style="border-radius: 8px;">
                            <option value="">Pilih Penanggung Jawab</option>
                            @if(isset($units) && $units->count() > 0)
                                @foreach($units as $unit)
                                    <option value="{{ $unit }}" {{ request('penanggung_jawab') == $unit ? 'selected' : '' }}>{{ $unit }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-success px-4 py-2 fw-bold d-flex align-items-center gap-2" style="border-radius: 8px; background-color: #28a745;">
                            Cari <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>

            <!-- Table Info -->
            <div class="d-flex justify-content-between align-items-center mb-3">
                <p class="mb-0 text-muted small">
                    Showing <span class="fw-bold">{{ $items->firstItem() ?? 0 }}-{{ $items->lastItem() ?? 0 }}</span> of <span class="fw-bold">{{ $items->total() }}</span> items.
                </p>
            </div>

            <!-- Table -->
            <div class="table-responsive">
                <table class="table table-bordered align-middle text-center small" style="min-width: 1500px; border-color: #dee2e6;">
                    <thead style="background-color: #f8f9fa;">
                        <tr class="text-primary fw-bold align-middle">
                            <th style="width: 50px;">#</th>
                            <th>PENANGGUNG JAWAB</th>
                            <th>INFORMASI</th>
                            <th>JENIS INFORMASI</th>
                            <th>RINGKASAN INFORMASI</th>
                            <th>PEJABAT YANG MENGUASAI INFORMASI</th>
                            <th>PENERBIT INFORMASI</th>
                            <th>BENTUK INFORMASI YANG TERSEDIA</th>
                            <th>TEMPAT PEMBUATAN</th>
                            <th>WAKTU PEMBUATAN</th>
                            <th>JANGKA WAKTU PENYIMPANAN / RETENSI WAKTU</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($items as $item)
                        <tr>
                            <td class="fw-bold">{{ ($items->currentPage() - 1) * $items->perPage() + $loop->iteration }}</td>
                            <td class="text-start">{{ $item->penanggung_jawab }}</td>
                            <td class="text-start fw-bold">{{ $item->judul_informasi }}</td>
                            <td><span class="badge bg-info text-dark text-uppercase">{{ str_replace('informasi-', '', $item->kategori) }}</span></td>
                            <td class="text-start">{!! $item->isi_informasi !!}</td>
                            <td>{{ $item->pejabat_penguasa }}</td>
                            <td>{{ $item->penerbit_informasi }}</td>
                            <td>{{ $item->bentuk_informasi }}</td>
                            <td>{{ $item->tempat_pembuatan }}</td>
                            <td>{{ $item->waktu_pembuatan }}</td>
                            <td>{{ $item->jangka_waktu }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="10" class="py-5 text-muted">Data tidak ditemukan.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4 d-flex justify-content-center">
                {{ $items->links('pagination::bootstrap-4') }}
            </div>
        </div>
    </div>

    @include('footer')

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>AOS.init({duration: 800, once: true});</script>
</body>
</html>
