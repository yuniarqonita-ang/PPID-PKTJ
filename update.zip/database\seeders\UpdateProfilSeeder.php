<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UpdateProfilSeeder extends Seeder
{
    public function run()
    {
        // ±300 kata - sesuai permintaan, mengacu pada profil ppid.dephub.go.id
        $profil = "Sejak diberlakukannya Undang-Undang Nomor 14 Tahun 2008 Tentang Keterbukaan Informasi Publik (UU KIP) secara efektif pada tanggal 30 April 2010, seluruh badan publik di Indonesia didorong untuk mengambil satu langkah maju ke depan — menjadi lebih transparan dan akuntabel dalam mengelola sumber daya publik. UU KIP merupakan instrumen hukum yang mengikat dan menjadi tonggak bagi seluruh rakyat Indonesia untuk bersama-sama mengawasi secara langsung pelayanan publik yang diselenggarakan oleh badan publik.

Keterbukaan informasi adalah salah satu pilar penting yang mendorong terciptanya tata kelola pemerintahan yang baik (good governance). Melalui keterbukaan ini, masyarakat dapat berperan aktif dalam proses pengambilan kebijakan serta mengawasi penyelenggaraan layanan publik yang dijalankan oleh Politeknik Keselamatan Transportasi Jalan (PKTJ) selaku Unit Pelaksana Teknis (UPT) di bawah Direktorat Jenderal Perhubungan Darat, Kementerian Perhubungan Republik Indonesia.

Dalam rangka memenuhi amanat UU KIP, PKTJ membentuk Pejabat Pengelola Informasi dan Dokumentasi (PPID). PPID PKTJ bertugas merencanakan, mengorganisasikan, melaksanakan, dan mengawasi pengelolaan informasi dan dokumentasi di lingkungan PKTJ. PPID bertanggung jawab dalam menyimpan, mendokumentasikan, menyediakan, dan memberikan pelayanan informasi kepada publik dengan cepat, tepat waktu, dan dengan biaya yang terjangkau.

Visi PPID PKTJ adalah terwujudnya pelayanan informasi publik yang terbuka, mudah diakses, tepat waktu, dan dapat dipertanggungjawabkan. Hal ini sejalan dengan komitmen PKTJ sebagai institusi pendidikan vokasi di bidang keselamatan transportasi jalan yang terus mengutamakan nilai integritas dan profesionalisme dalam setiap aspek layanan kepada masyarakat.

Kami berkomitmen untuk terus meningkatkan kualitas pelayanan informasi publik. Dengan mengedepankan prinsip transparansi dan akuntabilitas, PPID PKTJ berupaya menyediakan informasi yang akurat, mutakhir, dan mudah diakses oleh seluruh elemen masyarakat, sehingga kepercayaan publik terhadap institusi dapat terus terjaga dan ditingkatkan.";

        DB::table('profil_ppids')->updateOrInsert(
            ['type' => 'profil'],
            [
                'judul'          => 'Profil PPID',
                'konten_pembuka' => $profil,
                'gambaran'       => 'Berkomitmen menyelenggarakan pelayanan informasi publik yang transparan, akuntabel, dan profesional di lingkungan Politeknik Keselamatan Transportasi Jalan (PKTJ).',
                'konten_detail'  => '',
            ]
        );
    }
}
