@extends('layouts.app')

@section('content')
<div class="min-h-screen bg-[#f8f9fa] p-4 md:p-6 w-full">
    <div class="w-full space-y-6">
        
        <!-- HEADER SECTION -->
        <div class="flex items-center justify-between gap-4">
            <div>
                <a href="{{ route('admin.faq.index') }}" class="inline-flex items-center text-[#004a99] hover:text-blue-700 transition-colors mb-2 font-semibold">
                    <i class="fas fa-arrow-left mr-2"></i> Kembali ke Daftar FAQ
                </a>
                <h1 class="text-3xl font-black text-[#004a99] uppercase tracking-tight">
                    <i class="fas fa-edit mr-2"></i> Edit FAQ
                </h1>
                <p class="text-gray-500 font-medium font-medium mt-1">Lakukan penyesuaian pada FAQ yang sudah ada</p>
            </div>
        </div>

        <!-- FORM CARD -->
        <div class="bg-white rounded-2xl shadow-xl ring-1 ring-gray-200 overflow-hidden border-t-4 border-[#ffc107]">
            <form action="{{ route('admin.faq.update', $faq) }}" method="POST" class="p-6 md:p-10">
                @csrf
                @method('PUT')
                
                <div class="space-y-8">
                    <!-- MAIN CONTENT -->
                    <div class="space-y-6">
                        
                        <!-- PERTANYAAN -->
                        <div class="space-y-2">
                            <label for="pertanyaan" class="block text-sm font-bold text-gray-700 uppercase tracking-wide">
                                <i class="fas fa-question text-[#ffc107] mr-1"></i> Pertanyaan <span class="text-red-500">*</span>
                            </label>
                            <input type="text" name="pertanyaan" id="pertanyaan" value="{{ old('pertanyaan', $faq->pertanyaan) }}" required
                                class="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#004a99] focus:border-transparent transition-all shadow-sm"
                                placeholder="Masukkan pertanyaan...">
                            @error('pertanyaan') <p class="text-red-500 text-xs mt-1 font-bold">{{ $message }}</p> @enderror
                        </div>

                        <!-- JAWABAN (TinyMCE) -->
                        <div class="space-y-2">
                            <label for="editor_faq_edit" class="block text-sm font-bold text-gray-700 uppercase tracking-wide">
                                <i class="fas fa-comment-dots text-[#ffc107] mr-1"></i> Jawaban Lengkap <span class="text-red-500">*</span>
                            </label>
                            <div class="rounded-xl overflow-hidden border border-gray-300">
                                <textarea name="jawaban" id="editor_faq_edit" class="tinymce-editor">{{ old('jawaban', $faq->jawaban) }}</textarea>
                            </div>
                            @error('jawaban') <p class="text-red-500 text-xs mt-1 font-bold">{{ $message }}</p> @enderror
                        </div>


                    </div>

                    <!-- SIDEBAR INFO (BELOW) -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                        <div class="bg-blue-50 border-l-4 border-[#004a99] p-6 rounded-r-2xl">
                            <h3 class="text-md font-bold text-[#004a99] mb-3 uppercase flex items-center">
                                <i class="fas fa-history mr-2"></i> Info Update
                            </h3>
                            <div class="text-xs text-blue-800 space-y-2 font-medium">
                                <p><strong>Dibuat:</strong> {{ $faq->created_at->translatedFormat('d F Y') }}</p>
                                <p><strong>Update Terakhir:</strong> {{ $faq->updated_at->diffForHumans() }}</p>
                            </div>
                        </div>

                        <div class="bg-[#004a99] rounded-2xl p-6 text-white shadow-lg">
                            <p class="text-xs opacity-90 leading-relaxed font-medium">
                                <i class="fas fa-lightbulb mr-1 text-[#ffc107]"></i> Tips: Usahakan jawaban tidak terlalu panjang agar mudah dibaca di tampilan mobile.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- ACTIONS -->
                <div class="mt-10 pt-6 border-t border-gray-100 flex flex-col md:flex-row justify-end gap-3">
                    <button type="button" onclick="window.location='{{ route('admin.faq.index') }}'" class="px-6 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-all flex items-center justify-center">
                        <i class="fas fa-times mr-2"></i> Batal
                    </button>
                    <button type="submit" class="px-8 py-3 bg-gradient-to-r from-[#004a99] to-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40 transform hover:scale-[1.02] transition-all flex items-center justify-center">
                        <i class="fas fa-save mr-2 text-[#ffc107]"></i> Simpan Perubahan FAQ
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>
@endsection
